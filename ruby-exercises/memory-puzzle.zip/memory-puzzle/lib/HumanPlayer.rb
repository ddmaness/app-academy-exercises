class HumanPlayer
    def prompt
        p "what row and column would you like to reveal?"
    end

    def get_input
        gets
    end
end