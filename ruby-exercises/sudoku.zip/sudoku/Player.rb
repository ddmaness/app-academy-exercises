class Player
    def initialize
        
    end

    def prompt
        p 'choose a position and value: ex. 2,2 7'
        input = gets.chomp 
    end
end