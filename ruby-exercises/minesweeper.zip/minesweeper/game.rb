require_relative "board"
require "byebug"

class Game
    def initialize
        @board = Board.new
    end

    def play_round
        coords = ask_for_coordinates
        command = ask_for_command
        @board.update(coords, command)
    end

    def ask_for_coordinates
        print "what square would you like to target --- ex: (2, 3)\n"
        print "> "
        coords = parse_coords(gets.chomp)
        if coords_are_valid?(coords)
            coords
        else
            p "please make sure your coordinates are in the form of NUMBER COMMA NUMBER and are within the bound of the board"
            ask_for_coordinates
        end
    end

    def parse_coords(input)
        input.split(',').map! {|val| val.to_i}
    end

    def coords_are_valid?(coords)
        coords.all? {|coord| coord.between?(0, @board.dimensions - 1)}
    end

    def ask_for_command
        print "would you like to reveal (r) or flag (f) this square\n"
        print "> "
        command = gets.chomp
        if command_is_valid?(command)
            command
        else
            p "please enter a valid command ('r' for reveal or 'f' for flag)"
            ask_for_command
        end
    end

    def command_is_valid?(command)
        command == 'r' || command == 'f'
    end

    def run
        until @board.solved? || @board.is_lost?
            @board.render
            play_round
        end
        if @board.is_lost?
            @board.render
            p "kaboom"
        else
            @board.render
            p "you win!"
        end
    end
end

game = Game.new
game.run