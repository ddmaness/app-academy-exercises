

class Tile
    def initialize(board, coord, has_mine)
        @has_mine = has_mine
        @coord = coord
        @board = board
        @revealed = false
        @flagged = false
        @display_value = "*"
    end
    
    def board
        @board
    end

    def inspect_surrounding_tiles
        inner_tile = false
    end

    def check_surrounding_tiles_for_bombs
        mine_count = 0
        x, y = @coord
        checked_tiles = []
        ((x - 1)..(x+1)).each do |x_coord|
            ((y-1)..(y+1)).each do |y_coord|
                unless x_coord < 0 || y_coord < 0 || x_coord >= @board.length || y_coord >= @board.length || (x_coord == x && y_coord == y)
                    tile = @board[x_coord][y_coord]
                    checked_tiles << tile
                    mine_count += 1 if tile.has_mine?
                end
            end
        end
        if mine_count > 0
            @display_value = mine_count
        else
            @display_value = "_"
            checked_tiles.each {|tile| tile.reveal if !tile.revealed?}
        end
    end

    def display_value
        @display_value
    end

    def reveal
        if !@flagged
            @revealed = true
            if @has_mine
                @display_value = "B"
            else
                check_surrounding_tiles_for_bombs
            end
        end
    end

    def revealed?
        @revealed
    end

    def has_mine?
        @has_mine
    end

    def flag
        @flagged = !@flagged
        if @flagged
            @display_value = "F"
        else
            @display_value = "*"
        end
    end
end