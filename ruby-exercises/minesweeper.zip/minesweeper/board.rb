require_relative 'tile'

class Board
    def initialize
       @board = Board.generate_board 
       @game_over = false
    end

    def self.generate_board
        @board = Board.generate_empty_board
        Board.populate_board(@board)
    end

    def self.generate_empty_board
        Array.new(9) do |i|
            Array.new(9)
        end
    end

    def self.populate_board(board)
        board.each_with_index do |row, r_index|
            row.map!.with_index do |col, c_index|
                has_mine = false
                random_val = rand(1..40)
                if random_val == 1
                    has_mine = true
                end
                board[r_index][c_index] = Tile.new(@board, [r_index, c_index], has_mine)
            end
        end
        board
    end

    def render
        @board.each_with_index do |row, r_index|
            row.each_with_index do |col, c_index|
                print "#{@board[r_index][c_index].display_value} "
            end
            print "\n"
        end
    end

    def solved?
        @board.each_with_index do |row, r_index|
            row.each_with_index do |col, c_index|
                tile = @board[r_index][c_index]
                if !tile.has_mine? && !tile.revealed?
                    return false
                end
            end
        end
        true
    end

    def end_game
        @game_over = true
    end

    def is_lost?
        @game_over
    end

    def check_for_loss
        @board.each do |row|
            row.each do |tile|
                if tile.revealed? && tile.has_mine?
                    end_game
                end
            end
        end
    end

    def dimensions
        @board.length
    end

    def update (coords, command)
        x, y = coords
        tile = @board[x][y]
        if command == 'f'
            tile.flag
        elsif command == 'r'
            tile.reveal
            check_for_loss
        end
    end
end